﻿namespace DrinkMachine
{
    partial class drinkMachineScreen
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.ctnDrinks = new System.Windows.Forms.GroupBox();
            this.btnGrapeJuice = new System.Windows.Forms.Button();
            this.btnOrangeJuice = new System.Windows.Forms.Button();
            this.btnGuarana = new System.Windows.Forms.Button();
            this.btnCoke = new System.Windows.Forms.Button();
            this.ctnSize = new System.Windows.Forms.GroupBox();
            this.btnSize700ml = new System.Windows.Forms.Button();
            this.btnSize500ml = new System.Windows.Forms.Button();
            this.btnSize300ml = new System.Windows.Forms.Button();
            this.ctnAdditional = new System.Windows.Forms.GroupBox();
            this.btnNoIce = new System.Windows.Forms.Button();
            this.btnIce = new System.Windows.Forms.Button();
            this.ctnPlaceToEat = new System.Windows.Forms.GroupBox();
            this.btnTakeOut = new System.Windows.Forms.Button();
            this.btnEatIn = new System.Windows.Forms.Button();
            this.ctnOrderSummary = new System.Windows.Forms.GroupBox();
            this.lblIceQuantitySelected = new System.Windows.Forms.Label();
            this.lblCupTypeSelected = new System.Windows.Forms.Label();
            this.lblSizeSelected = new System.Windows.Forms.Label();
            this.lblDrinkSelected = new System.Windows.Forms.Label();
            this.lblPlaceToEatSelected = new System.Windows.Forms.Label();
            this.lblIceQuantity = new System.Windows.Forms.Label();
            this.lblSize = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDrink = new System.Windows.Forms.Label();
            this.lblPlaceToEat = new System.Windows.Forms.Label();
            this.btnCompleteOrder = new System.Windows.Forms.Button();
            this.ctnDrinks.SuspendLayout();
            this.ctnSize.SuspendLayout();
            this.ctnAdditional.SuspendLayout();
            this.ctnPlaceToEat.SuspendLayout();
            this.ctnOrderSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.Location = new System.Drawing.Point(12, 12);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(75, 36);
            this.btnNewOrder.TabIndex = 0;
            this.btnNewOrder.Text = "New Order";
            this.btnNewOrder.UseVisualStyleBackColor = true;
            this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
            // 
            // btnReset
            // 
            this.btnReset.Enabled = false;
            this.btnReset.Location = new System.Drawing.Point(93, 12);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 36);
            this.btnReset.TabIndex = 1;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // ctnDrinks
            // 
            this.ctnDrinks.Controls.Add(this.btnGrapeJuice);
            this.ctnDrinks.Controls.Add(this.btnOrangeJuice);
            this.ctnDrinks.Controls.Add(this.btnGuarana);
            this.ctnDrinks.Controls.Add(this.btnCoke);
            this.ctnDrinks.Enabled = false;
            this.ctnDrinks.Location = new System.Drawing.Point(12, 161);
            this.ctnDrinks.Name = "ctnDrinks";
            this.ctnDrinks.Size = new System.Drawing.Size(435, 105);
            this.ctnDrinks.TabIndex = 2;
            this.ctnDrinks.TabStop = false;
            this.ctnDrinks.Text = "Select Drink";
            // 
            // btnGrapeJuice
            // 
            this.btnGrapeJuice.Location = new System.Drawing.Point(325, 24);
            this.btnGrapeJuice.Name = "btnGrapeJuice";
            this.btnGrapeJuice.Size = new System.Drawing.Size(78, 64);
            this.btnGrapeJuice.TabIndex = 0;
            this.btnGrapeJuice.Text = "Grape Juice";
            this.btnGrapeJuice.UseVisualStyleBackColor = true;
            this.btnGrapeJuice.Click += new System.EventHandler(this.selectDrink_Click);
            // 
            // btnOrangeJuice
            // 
            this.btnOrangeJuice.Location = new System.Drawing.Point(232, 24);
            this.btnOrangeJuice.Name = "btnOrangeJuice";
            this.btnOrangeJuice.Size = new System.Drawing.Size(78, 64);
            this.btnOrangeJuice.TabIndex = 0;
            this.btnOrangeJuice.Text = "Orange Juice";
            this.btnOrangeJuice.UseVisualStyleBackColor = true;
            this.btnOrangeJuice.Click += new System.EventHandler(this.selectDrink_Click);
            // 
            // btnGuarana
            // 
            this.btnGuarana.Location = new System.Drawing.Point(135, 24);
            this.btnGuarana.Name = "btnGuarana";
            this.btnGuarana.Size = new System.Drawing.Size(78, 64);
            this.btnGuarana.TabIndex = 0;
            this.btnGuarana.Text = "Guarana";
            this.btnGuarana.UseVisualStyleBackColor = true;
            this.btnGuarana.Click += new System.EventHandler(this.selectDrink_Click);
            // 
            // btnCoke
            // 
            this.btnCoke.Location = new System.Drawing.Point(40, 24);
            this.btnCoke.Name = "btnCoke";
            this.btnCoke.Size = new System.Drawing.Size(78, 64);
            this.btnCoke.TabIndex = 0;
            this.btnCoke.Text = "Coke";
            this.btnCoke.UseVisualStyleBackColor = true;
            this.btnCoke.Click += new System.EventHandler(this.selectDrink_Click);
            // 
            // ctnSize
            // 
            this.ctnSize.Controls.Add(this.btnSize700ml);
            this.ctnSize.Controls.Add(this.btnSize500ml);
            this.ctnSize.Controls.Add(this.btnSize300ml);
            this.ctnSize.Enabled = false;
            this.ctnSize.Location = new System.Drawing.Point(12, 288);
            this.ctnSize.Name = "ctnSize";
            this.ctnSize.Size = new System.Drawing.Size(435, 89);
            this.ctnSize.TabIndex = 2;
            this.ctnSize.TabStop = false;
            this.ctnSize.Text = "Select Size";
            // 
            // btnSize700ml
            // 
            this.btnSize700ml.Location = new System.Drawing.Point(279, 18);
            this.btnSize700ml.Name = "btnSize700ml";
            this.btnSize700ml.Size = new System.Drawing.Size(75, 61);
            this.btnSize700ml.TabIndex = 0;
            this.btnSize700ml.Text = "700ml";
            this.btnSize700ml.UseVisualStyleBackColor = true;
            this.btnSize700ml.Click += new System.EventHandler(this.selectSize_Click);
            // 
            // btnSize500ml
            // 
            this.btnSize500ml.Location = new System.Drawing.Point(177, 18);
            this.btnSize500ml.Name = "btnSize500ml";
            this.btnSize500ml.Size = new System.Drawing.Size(75, 61);
            this.btnSize500ml.TabIndex = 0;
            this.btnSize500ml.Text = "500ml";
            this.btnSize500ml.UseVisualStyleBackColor = true;
            this.btnSize500ml.Click += new System.EventHandler(this.selectSize_Click);
            // 
            // btnSize300ml
            // 
            this.btnSize300ml.Location = new System.Drawing.Point(77, 18);
            this.btnSize300ml.Name = "btnSize300ml";
            this.btnSize300ml.Size = new System.Drawing.Size(75, 61);
            this.btnSize300ml.TabIndex = 0;
            this.btnSize300ml.Text = "300ml";
            this.btnSize300ml.UseVisualStyleBackColor = true;
            this.btnSize300ml.Click += new System.EventHandler(this.selectSize_Click);
            // 
            // ctnAdditional
            // 
            this.ctnAdditional.Controls.Add(this.btnNoIce);
            this.ctnAdditional.Controls.Add(this.btnIce);
            this.ctnAdditional.Enabled = false;
            this.ctnAdditional.Location = new System.Drawing.Point(12, 398);
            this.ctnAdditional.Name = "ctnAdditional";
            this.ctnAdditional.Size = new System.Drawing.Size(435, 83);
            this.ctnAdditional.TabIndex = 2;
            this.ctnAdditional.TabStop = false;
            this.ctnAdditional.Text = "Select Additional";
            // 
            // btnNoIce
            // 
            this.btnNoIce.Location = new System.Drawing.Point(216, 19);
            this.btnNoIce.Name = "btnNoIce";
            this.btnNoIce.Size = new System.Drawing.Size(75, 55);
            this.btnNoIce.TabIndex = 0;
            this.btnNoIce.Text = "No Ice";
            this.btnNoIce.UseVisualStyleBackColor = true;
            this.btnNoIce.Click += new System.EventHandler(this.selectIceQuantity_Click);
            // 
            // btnIce
            // 
            this.btnIce.Location = new System.Drawing.Point(119, 19);
            this.btnIce.Name = "btnIce";
            this.btnIce.Size = new System.Drawing.Size(75, 55);
            this.btnIce.TabIndex = 0;
            this.btnIce.Text = "Ice";
            this.btnIce.UseVisualStyleBackColor = true;
            this.btnIce.Click += new System.EventHandler(this.selectIceQuantity_Click);
            // 
            // ctnPlaceToEat
            // 
            this.ctnPlaceToEat.Controls.Add(this.btnTakeOut);
            this.ctnPlaceToEat.Controls.Add(this.btnEatIn);
            this.ctnPlaceToEat.Enabled = false;
            this.ctnPlaceToEat.Location = new System.Drawing.Point(12, 71);
            this.ctnPlaceToEat.Name = "ctnPlaceToEat";
            this.ctnPlaceToEat.Size = new System.Drawing.Size(435, 74);
            this.ctnPlaceToEat.TabIndex = 2;
            this.ctnPlaceToEat.TabStop = false;
            this.ctnPlaceToEat.Text = "Select Place to Eat";
            // 
            // btnTakeOut
            // 
            this.btnTakeOut.Location = new System.Drawing.Point(216, 17);
            this.btnTakeOut.Name = "btnTakeOut";
            this.btnTakeOut.Size = new System.Drawing.Size(75, 46);
            this.btnTakeOut.TabIndex = 0;
            this.btnTakeOut.Text = "Take Out";
            this.btnTakeOut.UseVisualStyleBackColor = true;
            this.btnTakeOut.Click += new System.EventHandler(this.selectPlaceToEat_Click);
            // 
            // btnEatIn
            // 
            this.btnEatIn.Location = new System.Drawing.Point(119, 17);
            this.btnEatIn.Name = "btnEatIn";
            this.btnEatIn.Size = new System.Drawing.Size(75, 46);
            this.btnEatIn.TabIndex = 0;
            this.btnEatIn.Text = "Eat In";
            this.btnEatIn.UseVisualStyleBackColor = true;
            this.btnEatIn.Click += new System.EventHandler(this.selectPlaceToEat_Click);
            // 
            // ctnOrderSummary
            // 
            this.ctnOrderSummary.Controls.Add(this.lblIceQuantitySelected);
            this.ctnOrderSummary.Controls.Add(this.lblCupTypeSelected);
            this.ctnOrderSummary.Controls.Add(this.lblSizeSelected);
            this.ctnOrderSummary.Controls.Add(this.lblDrinkSelected);
            this.ctnOrderSummary.Controls.Add(this.lblPlaceToEatSelected);
            this.ctnOrderSummary.Controls.Add(this.lblIceQuantity);
            this.ctnOrderSummary.Controls.Add(this.lblSize);
            this.ctnOrderSummary.Controls.Add(this.label1);
            this.ctnOrderSummary.Controls.Add(this.lblDrink);
            this.ctnOrderSummary.Controls.Add(this.lblPlaceToEat);
            this.ctnOrderSummary.Location = new System.Drawing.Point(473, 72);
            this.ctnOrderSummary.Name = "ctnOrderSummary";
            this.ctnOrderSummary.Size = new System.Drawing.Size(214, 137);
            this.ctnOrderSummary.TabIndex = 2;
            this.ctnOrderSummary.TabStop = false;
            this.ctnOrderSummary.Text = "Order Summary";
            // 
            // lblIceQuantitySelected
            // 
            this.lblIceQuantitySelected.AutoSize = true;
            this.lblIceQuantitySelected.Location = new System.Drawing.Point(129, 109);
            this.lblIceQuantitySelected.Name = "lblIceQuantitySelected";
            this.lblIceQuantitySelected.Size = new System.Drawing.Size(36, 15);
            this.lblIceQuantitySelected.TabIndex = 9;
            this.lblIceQuantitySelected.Text = "None";
            // 
            // lblCupTypeSelected
            // 
            this.lblCupTypeSelected.AutoSize = true;
            this.lblCupTypeSelected.Location = new System.Drawing.Point(129, 67);
            this.lblCupTypeSelected.Name = "lblCupTypeSelected";
            this.lblCupTypeSelected.Size = new System.Drawing.Size(36, 15);
            this.lblCupTypeSelected.TabIndex = 8;
            this.lblCupTypeSelected.Text = "None";
            // 
            // lblSizeSelected
            // 
            this.lblSizeSelected.AutoSize = true;
            this.lblSizeSelected.Location = new System.Drawing.Point(129, 89);
            this.lblSizeSelected.Name = "lblSizeSelected";
            this.lblSizeSelected.Size = new System.Drawing.Size(36, 15);
            this.lblSizeSelected.TabIndex = 7;
            this.lblSizeSelected.Text = "None";
            // 
            // lblDrinkSelected
            // 
            this.lblDrinkSelected.AutoSize = true;
            this.lblDrinkSelected.Location = new System.Drawing.Point(129, 46);
            this.lblDrinkSelected.Name = "lblDrinkSelected";
            this.lblDrinkSelected.Size = new System.Drawing.Size(36, 15);
            this.lblDrinkSelected.TabIndex = 6;
            this.lblDrinkSelected.Text = "None";
            // 
            // lblPlaceToEatSelected
            // 
            this.lblPlaceToEatSelected.AutoSize = true;
            this.lblPlaceToEatSelected.Location = new System.Drawing.Point(129, 23);
            this.lblPlaceToEatSelected.Name = "lblPlaceToEatSelected";
            this.lblPlaceToEatSelected.Size = new System.Drawing.Size(36, 15);
            this.lblPlaceToEatSelected.TabIndex = 5;
            this.lblPlaceToEatSelected.Text = "None";
            // 
            // lblIceQuantity
            // 
            this.lblIceQuantity.AutoSize = true;
            this.lblIceQuantity.Location = new System.Drawing.Point(7, 109);
            this.lblIceQuantity.Name = "lblIceQuantity";
            this.lblIceQuantity.Size = new System.Drawing.Size(72, 15);
            this.lblIceQuantity.TabIndex = 4;
            this.lblIceQuantity.Text = "Ice quantity:";
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(7, 89);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(30, 15);
            this.lblSize.TabIndex = 3;
            this.lblSize.Text = "Size:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cup type:";
            // 
            // lblDrink
            // 
            this.lblDrink.AutoSize = true;
            this.lblDrink.Location = new System.Drawing.Point(7, 46);
            this.lblDrink.Name = "lblDrink";
            this.lblDrink.Size = new System.Drawing.Size(38, 15);
            this.lblDrink.TabIndex = 1;
            this.lblDrink.Text = "Drink:";
            // 
            // lblPlaceToEat
            // 
            this.lblPlaceToEat.AutoSize = true;
            this.lblPlaceToEat.Location = new System.Drawing.Point(7, 23);
            this.lblPlaceToEat.Name = "lblPlaceToEat";
            this.lblPlaceToEat.Size = new System.Drawing.Size(71, 15);
            this.lblPlaceToEat.TabIndex = 0;
            this.lblPlaceToEat.Text = "Place to eat:";
            // 
            // btnCompleteOrder
            // 
            this.btnCompleteOrder.Location = new System.Drawing.Point(473, 225);
            this.btnCompleteOrder.Name = "btnCompleteOrder";
            this.btnCompleteOrder.Size = new System.Drawing.Size(214, 41);
            this.btnCompleteOrder.TabIndex = 3;
            this.btnCompleteOrder.Text = "Complete Order";
            this.btnCompleteOrder.UseVisualStyleBackColor = true;
            this.btnCompleteOrder.Click += new System.EventHandler(this.btnCompleteOrder_Click);
            // 
            // drinkMachineScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(703, 515);
            this.Controls.Add(this.btnCompleteOrder);
            this.Controls.Add(this.ctnOrderSummary);
            this.Controls.Add(this.ctnPlaceToEat);
            this.Controls.Add(this.ctnAdditional);
            this.Controls.Add(this.ctnSize);
            this.Controls.Add(this.ctnDrinks);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnNewOrder);
            this.Name = "drinkMachineScreen";
            this.Text = "Drink Machine";
            this.ctnDrinks.ResumeLayout(false);
            this.ctnSize.ResumeLayout(false);
            this.ctnAdditional.ResumeLayout(false);
            this.ctnPlaceToEat.ResumeLayout(false);
            this.ctnOrderSummary.ResumeLayout(false);
            this.ctnOrderSummary.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox ctnDrinks;
        private System.Windows.Forms.GroupBox ctnSize;
        private System.Windows.Forms.GroupBox ctnAdditional;
        private System.Windows.Forms.GroupBox ctnPlaceToEat;
        private System.Windows.Forms.GroupBox ctnOrderSummary;
        private System.Windows.Forms.Button btnGrapeJuice;
        private System.Windows.Forms.Button btnOrangeJuice;
        private System.Windows.Forms.Button btnGuarana;
        private System.Windows.Forms.Button btnCoke;
        private System.Windows.Forms.Button btnTakeOut;
        private System.Windows.Forms.Button btnEatIn;
        private System.Windows.Forms.Button btnSize700ml;
        private System.Windows.Forms.Button btnSize500ml;
        private System.Windows.Forms.Button btnSize300ml;
        private System.Windows.Forms.Button btnNoIce;
        private System.Windows.Forms.Button btnIce;
        private System.Windows.Forms.Label lblDrink;
        private System.Windows.Forms.Label lblPlaceToEat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCupTypeSelected;
        private System.Windows.Forms.Label lblSizeSelected;
        private System.Windows.Forms.Label lblDrinkSelected;
        private System.Windows.Forms.Label lblPlaceToEatSelected;
        private System.Windows.Forms.Label lblIceQuantity;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.Label lblIceQuantitySelected;
        private System.Windows.Forms.Button btnCompleteOrder;
    }
}

