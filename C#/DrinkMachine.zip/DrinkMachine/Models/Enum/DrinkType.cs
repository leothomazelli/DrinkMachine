﻿namespace Models.Enum
{
    public enum DrinkType
    {
        Soda,
        Juice 
    }
}
